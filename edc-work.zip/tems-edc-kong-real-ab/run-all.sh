#!/usr/bin/env bash
set -e

01-policy.sh
02-asset.sh
03-contractdef.sh
04-catalog.sh
05-negotiate.sh
